package com.datco.conversor

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var spFrom: Spinner
    private lateinit var spTo: Spinner
    private lateinit var chips: ChipGroup

    private var categoria: Categoria = Datos.categorias[0]
    private val formato = DecimalFormat(
        "#,##0.######",
        DecimalFormatSymbols(Locale("es", "AR"))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        result = findViewById(R.id.result)
        spFrom = findViewById(R.id.spFrom)
        spTo = findViewById(R.id.spTo)
        chips = findViewById(R.id.chips)

        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = convertir()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spFrom.onItemSelectedListener = listener
        spTo.onItemSelectedListener = listener

        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = convertir()
            override fun afterTextChanged(s: Editable?) {}
        })

        findViewById<MaterialButton>(R.id.btnSwap).setOnClickListener {
            val a = spFrom.selectedItemPosition
            val b = spTo.selectedItemPosition
            spFrom.setSelection(b)
            spTo.setSelection(a)
            convertir()
        }

        findViewById<MaterialButton>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("resultado", result.text))
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
        }

        var primero = -1
        Datos.categorias.forEachIndexed { i, c ->
            val chip = Chip(this).apply {
                id = View.generateViewId()
                text = c.nombre
                isCheckable = true
                tag = i
            }
            if (i == 0) primero = chip.id
            chips.addView(chip)
        }
        chips.setOnCheckedStateChangeListener { group, ids ->
            if (ids.isNotEmpty()) {
                val chip = group.findViewById<Chip>(ids[0])
                elegirCategoria(chip.tag as Int)
            }
        }
        chips.check(primero)
    }

    private fun elegirCategoria(i: Int) {
        categoria = Datos.categorias[i]
        val items = categoria.unidades.map { "${it.nombre} (${it.simbolo})" }
        spFrom.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spTo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spFrom.setSelection(0)
        spTo.setSelection(1)
        convertir()
    }

    private fun convertir() {
        if (spFrom.adapter == null || spTo.adapter == null) return
        val desde = spFrom.selectedItemPosition
        val hasta = spTo.selectedItemPosition
        if (desde < 0 || hasta < 0) return
        val valor = input.text.toString().replace(',', '.').toDoubleOrNull()
        if (valor == null) {
            result.text = "—"
            return
        }
        val r = categoria.convertir(valor, desde, hasta)
        val simbolo = categoria.unidades[hasta].simbolo
        result.text = "${dar(r)} $simbolo"
    }

    private fun dar(v: Double): String {
        if (v == 0.0) return "0"
        val a = abs(v)
        return if (a >= 1e12 || a < 1e-6) {
            String.format(Locale("es", "AR"), "%.6e", v)
        } else {
            formato.format(v)
        }
    }
}
